<?php 

//test.php

include 'header_inc.php';#defaults to header_inc.php

?>

here is some content



<?php
include 'footer_inc.php'; #defaults to footer_inc.php
?>
