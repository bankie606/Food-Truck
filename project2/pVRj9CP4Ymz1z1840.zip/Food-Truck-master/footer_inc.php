<?php ?>
<!-- footer include starts here -->
	
</div> <!-- div content closer-->
<div id="footerbox">
<tr>
		<td colspan="1">
		    
	        <p align="center"><em>&copy; Food Truck Company, 2007 - <?=$yearofoperation ?> </em></p>
		</td>
  </tr>
</div>    
</table>
</body>
</html>